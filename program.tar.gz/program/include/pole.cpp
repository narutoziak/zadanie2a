#include "pole.h"
#include <math.h>
#include <iostream>

using namespace std;

void pole::oblicz_pole(double a){
    double oblicz=a*a;
    cout<<"Pole kwadratu wynosi = "<<oblicz<<endl;
}
