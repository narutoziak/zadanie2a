#ifndef POLE_H
#define POLE_H


class pole
{
    public:
        void oblicz_pole(double a);
};

#endif // POLE_H
