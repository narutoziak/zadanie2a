#ifndef OBJETOSC_H
#define OBJETOSC_H


class objetosc
{
    public:
        void oblicz_objetosc(double a);
        void oblicz_polec(double a);
};

#endif // OBJETOSC_H
